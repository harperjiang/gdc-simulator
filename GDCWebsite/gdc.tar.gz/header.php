<div class="titlebar">
	<img style="float: left; width: 120px;" src="image/GDC-logo.png"></img>
	<img style="float: left; width: 600px;margin-right:30px;" src="image/cg_banner.png"></img> 
	<img style="float: left; height: 120px;" src="image/clarkson.jpg"></img>
</div>
<div class="clearer"></div>
