<div class="titlebar">
	<!-- img style="float: left; width: 120px;" src="image/GDC-logo.png"></img -->
	<a href="index.php"><img
		style="float: left; width: 840px; margin-right: 120px;"
		src="image/gdc_banner.png"></img> </a>
	<!-- img style="float: left; height: 120px;" src="image/clarkson.jpg"></img -->
</div>
<div class="clearer"></div>
