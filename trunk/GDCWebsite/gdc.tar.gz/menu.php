<div class="menubar">
	<a class="menu_main" href="index.php">Green Datacenter</a> 
		<a class="menu_item" href="index.php#part1">Introduction</a>
		<a class="menu_item" href="index.php#part2">Objectives</a>
		<a class="menu_item" href="index.php#part3">Benefits</a>
	<a class="menu_main" href="eng_design.php">Engineering Design</a> 
		<a class="menu_item" href="eng_design.php#part1">Components</a> 
		<a class="menu_item" href="eng_design.php#part2">Test Bench Organization</a> 
		<a class="menu_item" href="eng_demoarch.php">Demo Arch</a> 
		<a class="menu_item" href="eng_emulator.php">Emulator Design</a> 
	<a class="menu_main" href="gpower_study.php">Green Power Study</a> 
		<a class="menu_item" href="gpower_study.php#part1">Green Power Study</a> 
		<a class="menu_item" href="gpower_study.php#part2">Wind Power Downtime</a> 
	<a class="menu_main" href="wload_mig.php">Workloads Migration</a> 
		<a class="menu_item" href="compute_mig.php">Computation Migration</a> 
		<a class="menu_item" href="data_rep.php">Data Replication</a> 
	<a class="menu_main" href="system_demo.php">System Demos</a> 
		<a class="menu_item" href="livemig_demo.php">Live Migration Demo</a> 
		<a class="menu_item" href="dccon_demo.php">DC Connection Demo</a> 
		<a class="menu_item" href="other_demo.php">Other Demo</a> 
	<a class="menu_main" href="biz_eval.php">Business Model</a> 
		<a class="menu_item" href="biz_eval.php">Price Evaluation</a>
	<a class="menu_main" href="future.php">Future Scope</a> 
		<a class="menu_item" href="future.php">Larger Scale</a> 
		<a class="menu_item" href="future.php">New Technologies</a> 
	<a class="menu_main" href="about.php">About us</a> 
		<a class="menu_item" href="about.php#part1">Engineering members</a> 
		<a class="menu_item" href="about.php#part2">CS members</a> 
		<a class="menu_item" href="about.php#part3">Economics and Policy members</a> 
	<a class="menu_main" href="partner.php">Partnership</a>
	<a class="menu_main" href="resource.php">Resource</a>
</div>
